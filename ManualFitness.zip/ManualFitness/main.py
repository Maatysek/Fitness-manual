#introduction

print("Welcome to the fitness manual!")
name = input("What's your name?: ")

#greeting def function

def greet(name):
    print("Hi",name,"!")
greet(name)

#bmi calculation
def get_valid_input(vyzva):
    while True:
        try:
            value = float(input(vyzva))
            return value
        except ValueError:
            print("Invalid input. Please try it again.")

weight = get_valid_input("How much do you weigh? (kg): ")
height = get_valid_input("How tall are you? (m): ")
bmi = float(weight/(height**2))

#bmi results

print("Your BMI is:", str(bmi))
print("")
if bmi<=18.5:
    print("You are underweight! I recommend you to workout and eat more!")
    print("")
    bmi = 1
elif 18.5<=bmi<=24.9:
    print("You have normal bmi. You don't need to excercise. Have a nice day.")
    quit()
elif 25<=bmi<=29.9:
    print("You are overweight. Start excercising to get in shape!")
    print("")
    bmi = 2
elif 30<=bmi<=34.9:
    print("You are obese. Go on a diet and excercise frequently!")
    print("")
    bmi = 3
else:
    print("You are extremely obese! Go on a diet ASAP!")
    print("")
    bmi = 4


#response

print("Here are my recommendations:")
if bmi==1:
    print("Eat alot of protein and start lifting heavy weights.")
elif bmi==2:
    print("Start doing cardio and lift heavy weights.")
elif bmi==3:
    print("Go on a calorie-deficit and start doing alot of cardio.")
elif bmi==4:
    print("You're fat lol(me too[and what])")

rating = input("Did you enjoy this manual?(Yes/No): ")
if rating.lower() == "yes":
    print("Thanks for your feedback. Have a nice day.")
    quit()
else:
    print("Do it yourself then.")
    quit()